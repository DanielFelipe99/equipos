Las im�genes fueron tomadas de http://www.paninidigital.com
Im�gen del t�tulo tomada de http://www.tshirtstudio.com/t-shirts/1/1/art/football/pic-world-cup-t-shirts.jpg